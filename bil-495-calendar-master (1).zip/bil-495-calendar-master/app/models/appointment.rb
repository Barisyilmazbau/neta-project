class Appointment < ApplicationRecord
end
